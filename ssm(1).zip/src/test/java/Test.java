import com.guojx.service.IService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.sql.SQLException;

public class Test {
    @org.junit.Test
    public void test() throws SQLException {
        ApplicationContext ac =  new ClassPathXmlApplicationContext("classpath:application-context.xml");
        IService accountService = (IService) ac.getBean("accountService");
        accountService.FindAll();
    }
}
