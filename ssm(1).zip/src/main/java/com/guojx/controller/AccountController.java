package com.guojx.controller;

import com.guojx.domin.Account;
import com.guojx.domin.LoginVO;
import com.guojx.domin.TransferVO;
import com.guojx.service.IService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.sql.SQLException;
import java.util.List;


@Controller
@RequestMapping("/account")
public class AccountController {
    @Autowired
    private IService accountService;
    @RequestMapping("/findAll")
    public String findAll(Model model) throws SQLException {
        System.out.println("表现层：查询所有...");
        List<Account> list = accountService.FindAll();
        model.addAttribute("list",list);
        System.out.println(list);
        return "list";

    }
    @RequestMapping(value = "/saveAccount",method = RequestMethod.POST)
    public String saveAccount(@RequestBody Account account , HttpServletRequest request, HttpServletResponse response) throws SQLException {
        System.out.println("表现层：保存账户...");
        System.out.println(account);
        accountService.SaveAccount(account);
        System.out.println("保存成功");

        return "success";

    }
    @RequestMapping("/transfer")
    public void transfer(@RequestBody TransferVO transfer ,HttpServletResponse resp) throws SQLException {
        System.out.println("表现层：转账...");
        accountService.Transfer(transfer.getDrawee(), transfer.getPayee(), transfer.getMoney());
        resp.setHeader("transferStatus","success");



    }

    @RequestMapping("/saveAccount_react")
    public void saveAccount(String name,Double money) throws SQLException {
        System.out.println("表现层：保存账户...");
        Account account = new Account();
        account.setMoney(money);
        account.setName(name);
        accountService.SaveAccount(account);
        System.out.println("保存成功");
    }
    @RequestMapping("/login")
    public void Login(@RequestBody LoginVO account,HttpServletRequest req,HttpServletResponse resp) throws SQLException {
        System.out.println("表现层：登录....");
        String returnValue = accountService.Login(account);
        if(returnValue.equals("success")){
            HttpSession session = req.getSession();
            session.setAttribute("cardID",account.getCardID());
            resp.setHeader("sessionstatus","success");


        }else {
            resp.setHeader("sessionstatus", "timeout");

        }

    }
    @RequestMapping("/logout")
    public void Logout(HttpServletRequest resq, HttpServletResponse resp){
        System.out.println("表现层：注销...");
        HttpSession session = resq.getSession();
        session.invalidate();
        //resq.removeAttribute(session.getAttributeNames().toString());
        resp.setHeader("logoutStatus","success");
    }
}
